<script>
	jQuery(document).ready(function($) {
		let root_url = "<?php echo base_url(); ?>";
		customer_claim_table(root_url);
		delivery(root_url);
    });
</script>