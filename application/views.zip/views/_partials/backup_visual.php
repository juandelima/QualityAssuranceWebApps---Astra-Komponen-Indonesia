<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Kotor</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue kotor">-</button>
																	<input type="text" id="kotor" name="kotor" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Lecet</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue lecet">-</button>
																	<input type="text" id="lecet" name="lecet" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Tipis</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue tipis">-</button>
																	<input type="text" id="tipis" name="tipis" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Meler</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue meler">-</button>
																	<input type="text" id="meler" name="meler" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Nyerep</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue nyerep">-</button>
																	<input type="text" id="nyerep" name="nyerep" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">O Peel</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue opeel">-</button>
																	<input type="text" id="opeel" name="opeel" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Buram</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue buram">-</button>
																	<input type="text" id="buram" name="buram" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Over Cut</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue overcut">-</button>
																	<input type="text" id="overcut" name="overcut" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Burry</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue burry">-</button>
																	<input type="text" id="burry" name="burry" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Belang</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue belang">-</button>
																	<input type="text" id="belang" name="belang" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Ngeflek</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue ngeflek">-</button>
																	<input type="text" id="ngeflek" name="ngeflek" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Minyak</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue minyak">-</button>
																	<input type="text" id="minyak" name="minyak" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Dustray</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue dustray">-</button>
																	<input type="text" id="dustray" name="dustray" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Cat Kelupas</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue cat_kelupas">-</button>
																	<input type="text" id="cat_kelupas" name="cat_kelupas" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Bintik Air</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue b_air">-</button>
																	<input type="text" id="b_air" name="b_air" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Finishing Ng</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue f_ng">-</button>
																	<input type="text" id="f_ng" name="f_ng" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Serat</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue serat">-</button>
																	<input type="text" id="serat" name="serat" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Demotograph</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue d_graph">-</button>
																	<input type="text" id="d_graph" name="d_graph" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Lifting</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue lifting">-</button>
																	<input type="text" id="lifting" name="lifting" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Kusam</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue kusam">-</button>
																	<input type="text" id="kusam" name="kusam" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Flow Mark</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue f_mark">-</button>
																	<input type="text" id="f_mark" name="f_mark" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Legok</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue legok">-</button>
																	<input type="text" id="legok" name="legok" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Salah Type</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue s_type">-</button>
																	<input type="text" id="s_type" name="s_type" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Getting</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue getting">-</button>
																	<input type="text" id="getting" name="getting" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Part Campur</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue part_campur">-</button>
																	<input type="text" id="part_campur" name="part_campur" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Sinmark</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue sinmark">-</button>
																	<input type="text" id="sinmark" name="sinmark" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Gores</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue gores">-</button>
																	<input type="text" id="gores" name="gores" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Gloss</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue gloss">-</button>
																	<input type="text" id="gloss" name="gloss" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Patah Depan</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue p_depan">-</button>
																	<input type="text" id="p_depan" name="p_depan" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Patah Belakang</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue p_belakang">-</button>
																	<input type="text" id="p_belakang" name="p_belakang" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Patah Kanan</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue p_kanan">-</button>
																	<input type="text" id="p_kanan" name="p_kanan" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Patah Kiri</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue p_kiri">-</button>
																	<input type="text" id="p_kiri" name="p_kiri" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Silver</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue silver">-</button>
																	<input type="text" id="silver" name="silver" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Burn Mark</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue b_mark">-</button>
																	<input type="text" id="b_mark" name="b_mark" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Weld Line</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue w_line">-</button>
																	<input type="text" id="w_line" name="w_line" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Bubble</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue bubble">-</button>
																	<input type="text" id="bubble" name="bubble" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Black Dot</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue b_dot">-</button>
																	<input type="text" id="b_dot" name="b_dot" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">White Dot</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue w_dot">-</button>
																	<input type="text" id="w_dot" name="w_dot" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Isi Tidak Set</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue isi_tidak_set">-</button>
																	<input type="text" id="isi_tidak_set" name="isi_tidak_set" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Gompal</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue gompal">-</button>
																	<input type="text" id="gompal" name="gompal" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Salah label</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue s_label">-</button>
																	<input type="text" id="s_label" name="s_label" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Sobek terkena cutter</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue t_cutter">-</button>
																	<input type="text" id="t_cutter" name="t_cutter" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Terbentur (Sobek handling)</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue terbentur">-</button>
																	<input type="text" id="terbentur" name="terbentur" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Kereta (Sobek handling)</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue kereta">-</button>
																	<input type="text" id="kereta" name="kereta" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Terjatuh (Sobek handling)</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue terjatuh">-</button>
																	<input type="text" id="terjatuh" name="terjatuh" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Terkena Gun (Sobek handling)</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue terkena_gun">-</button>
																	<input type="text" id="terkena_gun" name="terkena_gun" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Sobek Handling</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue s_handling">-</button>
																	<input type="text" id="s_handling" name="s_handling" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Sobek Staples</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue s_steples">-</button>
																	<input type="text" id="s_steples" name="s_steples" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Staples Lepas</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue s_lepas">-</button>
																	<input type="text" id="s_lepas" name="s_lepas" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Keriput</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue keriput">-</button>
																	<input type="text" id="keriput" name="keriput" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Seaming Ng</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue seaming_ng">-</button>
																	<input type="text" id="seaming_ng" name="seaming_ng" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Nonjol</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue nonjol">-</button>
																	<input type="text" id="nonjol" name="nonjol" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>

													<div class="row" style="margin-bottom: 10px;">
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Seal Lepas</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue seal_lepas">-</button>
																	<input type="text" id="seal_lepas" name="seal_lepas" class="form-control size-1" value="0"/>
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left; ">Cover Ng</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue cover_ng">-</button>
																	<input type="text" id="cover_ng" name="cover_ng" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Belum Finishing</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue b_finishing">-</button>
																	<input type="text" id="b_finishing" name="b_finishing" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
														<div class="col-md-3">
															<label for="field-1" class="col-sm-5 control-label" style="text-align:left;">Foam Ng</label>
															<div class="col-sm-7">
																<div class="input-spinner">
																	<button type="button" class="btn btn-blue foam_ng">-</button>
																	<input type="text" id="foam_ng" name="foam_ng" class="form-control size-1" value="0" />
																	<button type="button" class="btn btn-blue">+</button>
																</div>
															</div>
														</div>
													</div>
				kotor = kotor || 0;
				lecet  = lecet || 0;
				tipis  = tipis || 0;
				meler  = meler || 0;
				nyerep  = nyerep || 0;
				opeel  = opeel || 0;
				buram  = buram || 0;
				overcut  = overcut || 0;
				burry  = burry || 0;
				belang  = belang || 0;
				ngeflek  = ngeflek || 0;
				minyak  = minyak || 0;
				dustray  = dustray || 0;
				cat_kelupas  = cat_kelupas || 0;
				b_air  = b_air || 0;
				f_ng  = f_ng || 0;
				serat  = serat || 0;
				d_graph  = d_graph || 0;
				lifting  = lifting || 0;
				kusam  = kusam || 0;
				f_mark  = f_mark || 0;
				legok  = legok || 0;
				s_type  = s_type || 0;
				getting  = getting || 0;
				part_campur  = part_campur || 0;
				sinmark  = sinmark || 0;
				gores  = gores || 0;
				gloss  = gloss || 0;
				p_depan  = p_depan || 0;
				p_belakang  = p_belakang || 0;
				p_kanan  = p_kanan || 0;
				p_kiri  = p_kiri || 0;
				silver  = silver || 0;
				b_mark  = b_mark || 0;
				w_line  = w_line || 0;
				bubble  = bubble || 0;
				b_dot  = b_dot || 0;
				w_dot  = w_dot || 0;
				isi_tidak_set  = isi_tidak_set || 0;
				gompal  = gompal || 0;
				s_label  = s_label || 0;
				t_cutter  = t_cutter || 0;
				terbentur  = terbentur || 0;
				kereta  = kereta || 0;
				terjatuh  = terjatuh || 0;
				terkena_gun  = terkena_gun || 0;
				s_handling  = s_handling || 0;
				s_lepas  = s_lepas || 0;
				keriput  = keriput || 0;
				seaming_ng  = seaming_ng || 0;
				nonjol  = nonjol || 0;
				seal_lepas  = seal_lepas || 0;
				cover_ng  = cover_ng || 0;
				b_finishing  = b_finishing || 0;
				foam_ng  = foam_ng || 0;
				deformasi  = deformasi || 0;
				patah  = patah || 0;
				incomplete_part  = incomplete_part || 0;
				e_mark  = e_mark || 0;
				short_shot  = short_shot || 0;
				material_asing  = material_asing || 0;
				pecah  = pecah || 0;
				stay_lepas  = stay_lepas || 0;
				salah_ulir  = salah_ulir || 0;
				visual_ta  = visual_ta || 0;
				ulir_ng  = ulir_ng || 0;
				rubber_ta  = rubber_ta || 0;
				hole_ng  = hole_ng || 0;
