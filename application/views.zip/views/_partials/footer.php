<footer class="main" style="margin-top: 130px;">
	&copy; 2019 <strong>QUALITY ASSURANCE DEPT</strong> - PT. ASTRA KOMPONEN INDONESIA
</footer>
