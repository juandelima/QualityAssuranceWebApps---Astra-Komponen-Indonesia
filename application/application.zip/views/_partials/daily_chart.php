<script>
    jQuery(document).ready(($) => {
		daily_chart("<?php echo base_url() ?>");
    });
</script>